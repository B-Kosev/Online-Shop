#pragma once
#include "stock.h"
#include "account.h"
#include "MyString.h"
#include "MyVector.h"
#include "Shop.h"

class shop
{
	int number_Stocks; //number of stocks in the file
	Vector<stock> products; //array with products
	account* user; //pointer to one user - not array - dynamic!!!
	
public:
	//constructors
	shop();
	shop(const shop& obj);
	~shop();
	
	//getters
	int getFileLines() const;
	int getNumberStocks() const;
	Vector<stock> getProducts();
	account* getUser() const;

	//setters
	void setUser(account*);

	//other
	shop& operator=(const shop& obj);
	void auth();
	void fillStocksArr();
	int menuInputValidation(int input, int lowerBound, int upperBound);
	void addToCart(int addByID);
	void removeFromCart(int removeByID);
	void createProduct();
	void updateDataToFile();
};