#include "stock.h"
#include <cstring>
#include <iostream>
using namespace std;

stock::stock()
{
	name = "";
	category = "";
	category_ID = 0;
	ID = 0;
	amount = 0;
	amountInCart = 0;
	price = 0.0;
	description = "";
}

stock::stock(String name, String category,int category_ID,int ID, int amount, int amountInCart, double price, String description)
{
	this->name = name;
	this->category = category;

	this->category_ID = category_ID;
	this->ID = ID;
	this->amount = amount;
	this->amountInCart = amountInCart;
	this->price = price;

	this->description = description;
}

String stock::getName() const
{
	return name;
}

String stock::getCategory() const
{
	return category;
}

int stock::getCategory_ID() const
{
	return category_ID;
}

int stock::getID() const
{
	return ID;
}

int stock::getAmount() const
{
	return amount;
}

int stock::getAmountInCart() const
{
	return amountInCart;
}

double stock::getPrice() const
{
	return price;
}

String stock::getDescription() const
{
	return description;
}

void stock::setName(String name)
{
	this->name = name;
}

void stock::setCategory(String category)
{
	this->category = category;
}

void stock::setCategory_ID(int category_ID)
{
	this->category_ID = category_ID;
}

void stock::setID(int ID)
{
	this->ID = ID;
}

void stock::setAmount(int amount)
{
	this->amount = amount;
}

void stock::setAmountInCart(int amountInCart)
{
	this->amountInCart = amountInCart;
}

void stock::setPrice(double price)
{
	this->price = price;
}

void stock::setDescription(String description)
{
	this->description = description;
}

void stock::setProduct(String name, String category, String description, int categoryID, int ID, int amount, int amountInCart, double price)
{
	this->name = name;
	this->category = category;
	this->description = description;
	this->category_ID = categoryID;
	this->ID = ID;
	this->amount = amount;
	this->amountInCart = amountInCart;
	this->price = price;
}

void stock::print() const
{
	cout << "\nProduct ID: " << ID << endl << "Name: " << name << endl << "Category: " << category << endl << "Amount: " << amount << endl << "Price: $" << price << endl << "Description: " << description << endl;
}

void stock::printForCart() const
{
	cout <<"\nProduct ID: "<<ID<<endl<< "Name: " << name << endl << "Price: $" << price << endl << "Description: " << description << endl<<"Amount in cart: "<<amountInCart<<endl;
}