#pragma once
#pragma warning(disable:4996)
#include "stock.h"
#include "MyString.h"
#include "MyVector.h"

class account 
{
	String username;
	String password;
	bool isAdmin;
	Vector<stock> shoppingCart; 
public:
	//constructors
	account();
	account(String, String);

	//getters
	String getUsername() const;
	String getPassword() const;
	bool getIsAdmin() const;
	Vector<stock>& getShoppingCart();

	//setters
	void setUsername(String);
	void setPassword(String);
	void setIsAdmin(bool);
	void setShoppingCart(Vector<stock>);

	//other
	void printUser() const;
	void printShoppingCart() const;
	bool buy(); //return true if a purchase is completed
	
};