#pragma once
#pragma warning(disable:4996)
#include "MyString.h"

class stock 
{
	String name;
	String category;
	String description;
	int category_ID;
	int ID;
	int amount;
	int amountInCart;
	double price;
public:
	//constructors
	stock();
	stock(String, String, int, int, int, int, double, String);

	//getters
	String getName() const;
	String getCategory() const;
	String getDescription() const;
	int getCategory_ID() const;
	int getID() const;
	int getAmount() const;
	int getAmountInCart() const;
	double getPrice() const;

	//setters
	void setName(String);
	void setCategory(String);
	void setCategory_ID(int);
	void setID(int);
	void setAmount(int);
	void setAmountInCart(int);
	void setPrice(double);
	void setDescription(String);
	void setProduct(String, String, String, int, int, int, int, double);

	//other
	void print() const;
	void printForCart() const;
};