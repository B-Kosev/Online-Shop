#include "Shop.h"
#include <fstream>
#include <iostream>
#include <windows.h>

#undef max

using namespace std;

shop::shop()
{
	number_Stocks = getFileLines();
	user = new account;
	products = new stock[number_Stocks];
	fillStocksArr();

}

shop::shop(const shop& obj)
{
	number_Stocks = obj.number_Stocks;
	user = new account;
	user->setIsAdmin(obj.getUser()->getIsAdmin());
	user->setPassword(obj.getUser()->getPassword());
	user->setUsername(obj.getUser()->getUsername());
	user->setShoppingCartSize(obj.getUser()->getShoppingCartSize());
	user->setShoppingCart(obj.getUser()->getShoppingCart());
	products = new stock[number_Stocks];
	for (int i = 0;i < number_Stocks;i++)
	{
		products[i] = obj.products[i];
	}
}

shop::~shop()
{
	delete[] products;
	delete user;
}

int shop::getFileLines() const
{
	int fileLines = 0;
	char* tempRead = new char[200];
	ifstream inFile;

	inFile.open("stocks.txt", ios::in);
	if (inFile.is_open())
	{
		while (!inFile.eof())
		{
			inFile.getline(tempRead, 200);
			fileLines++;
		}
	}
	inFile.close();
	delete[] tempRead;

	fileLines--;

	return fileLines;
}

int shop::getNumberStocks() const
{
	return number_Stocks;
}

stock* shop::getProducts() const
{
	return products;
}

account* shop::getUser() const
{
	return user;
}

void shop::setUser(account*obj)
{
	user = obj;
}

shop& shop::operator=(const shop& obj)
{
	if (this != &obj)
	{
		delete this->user;
		delete[] this->products;
		number_Stocks = obj.number_Stocks;
		user = new account;
		user->setIsAdmin(obj.getUser()->getIsAdmin());
		user->setPassword(obj.getUser()->getPassword());
		user->setUsername(obj.getUser()->getUsername());
		user->setShoppingCartSize(obj.getUser()->getShoppingCartSize());
		user->setShoppingCart(obj.getUser()->getShoppingCart());
		products = new stock[number_Stocks];
		for (int i = 0;i < number_Stocks;i++)
		{
			products[i] = obj.products[i];
		}
	}
	return *this;
}

void shop::auth()
{
START:
	cout << "Welcome to KoseBose Online Shop!";
	cout << "\n--------------------------------------------------------\n";
	cout << "\n1) Register\n";
	cout << "2) Login\n";
	cout << "\n--------------------------------------------------------\n";

	//variable for menu
	int logreg = 0;
	logreg = menuInputValidation(logreg, 1, 2);

	//file
	fstream authList;

	//register
	if (logreg == 1)
	{
		char username[20];
		char password[20];
		bool isAdmin = false;

		cout << "Enter username: ";
		cin >> username;

		char read_Username[20];
		char read_Password[20];

		bool registered = false;

		//open file for reading, check if username is already registered
		authList.open("auth.txt", ios::in);
		if (authList.is_open())
		{
			while (!authList.eof())
			{
				authList >> read_Username >> read_Password;
				if (strcmp(username, read_Username) == 0)
				{
					registered = true;
					break;
				}
			}

			if (registered)
			{
				cout << "User already registered!";
				Sleep(2000);
				system("CLS");
				authList.close();
				goto START;

			}
		}
		//else closes the file and opens it for writing and stores the data for the new user
		authList.close();
		authList.open("auth.txt", ios::app);
		authList << username << ' ';

		cout << "Enter password: ";
		cin >> password;

		authList << password << ' ' << isAdmin << endl;
		authList.close();
		cout << "Successfully registered!\n";
		cout << "\n--------------------------------------------------------\n";

		user->setUsername(username);
		user->setPassword(password);
		user->setIsAdmin(isAdmin);
		goto LOGIN;
	}

	//login new
	if (logreg == 2)
	{
	LOGIN:
		//input variables
		char attempt_Username[20];
		char attempt_Password[20];

		//stored variables in database
		char read_Username[20];
		char read_Password[20];
		bool read_IsAdmin;

		//check if correct
		bool correct_Username = false;

		//open file for reading
		authList.open("auth.txt", ios::in);

		//check if entered username exists in database
		cout << "\nLogin:\n";
		cout << "Enter username: ";
		cin >> attempt_Username;
		if (authList.is_open())
		{
			while (!authList.eof())
			{
				authList >> read_Username >> read_Password >> read_IsAdmin;
				correct_Username = false;

				//check if correct username
				if (strcmp(read_Username, attempt_Username) == 0)
				{
					correct_Username = true;
					cout << "Enter password: ";
					cin >> attempt_Password;

					//check if correct passowrd
					if (strcmp(read_Password, attempt_Password) == 0)
					{
						cout << "\nSuccessfully logged in!\n\n";
						user->setUsername(attempt_Username);
						user->setPassword(attempt_Password);
						user->setIsAdmin(read_IsAdmin);
						cout << "\n--------------------------------------------------------\n";
						authList.close();
						break;
					}
					else
					{
						cout << "Incorrect password!\n";
						authList.close();
						Sleep(2000);
						goto LOGIN;
					}
				}
			}
			//if not correct username
			if (!correct_Username)
			{
				cout << "Incorrect username!\n";
				authList.close();
				Sleep(2000);
				goto LOGIN;
			}
		}
	}
}

void shop::fillStocksArr()
{
	ifstream stock_fill;
	stock_fill.open("stocks.txt", ios::in);

	//temp variables
	char read_Name[50], read_Category[20], read_Description[100];
	int read_Amount, read_Category_ID, read_ID, read_AmountInCart;
	double read_Price;

	//fill array
	for (int i = 0;i < number_Stocks;i++)
	{
		if (stock_fill.is_open())
		{
			//read from file and fill data into object
			stock_fill >> read_Name >> read_Category >> read_Category_ID >> read_ID >> read_Amount >> read_AmountInCart >> read_Price;
			stock_fill.ignore();
			stock_fill.getline(read_Description, 100);

			products[i].setName(read_Name);
			products[i].setCategory(read_Category);
			products[i].setCategory_ID(read_Category_ID);
			products[i].setID(read_ID);
			products[i].setAmount(read_Amount);
			products[i].setAmountInCart(read_AmountInCart);
			products[i].setPrice(read_Price);
			products[i].setDescription(read_Description);

			//clear variables
			strcpy(read_Name, "");
			strcpy(read_Category, "");
			read_Category_ID = -1;
			read_ID = 0;
			read_Amount = -1;
			read_AmountInCart = -1;
			read_Price = -1.0;
			strcpy(read_Description, "");
		}
	}
	stock_fill.close();
}

int shop::menuInputValidation(int input, int lowerBound, int upperBound)
{
	while (true)
	{
		cin >> input;
		if (cin.fail())
		{
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << "Invalid input.\n";
			continue;
		}
		if (input >= lowerBound && input <= upperBound) break;
		cout << "Invalid input.\n";
	}
	return input;
}

void shop::addToCart(int addByID)
{
	if (addByID == 0) return;

	int addToCart = -1; //the index of the element in the array of products

	//find index of product in array by comparing with ID
	for (int i = 0;i < number_Stocks;i++)
	{
		if (addByID == products[i].getID())
		{
			addToCart = i;
			break;
		}
	}
	if (addToCart == -1)
	{
		cout << "There is no item with that ID.\n";
		Sleep(2000);
		return;
	}
	bool isInCart = false;

	//if size>0
	if (user->getShoppingCartSize()>0)
	{
		//if product already in cart
		for (int i = 0;i < user->getShoppingCartSize();i++)
		{
			if (user->getShoppingCart()[i].getID() == products[addToCart].getID())
			{
				user->getShoppingCart()[i].setAmountInCart(user->getShoppingCart()[i].getAmountInCart() + 1);
				user->getShoppingCart()[i].setAmount(user->getShoppingCart()[i].getAmount() - 1);
				products[addToCart].setAmount(products[addToCart].getAmount() - 1);
				isInCart = true;
				break;
			}
		}
		if (isInCart) return;

		//create new array with 1 element more to store new data
		stock* newShoppingCart = new stock[user->getShoppingCartSize() + 1];

		//copy old arr in new arr
		for (int i = 0;i < user->getShoppingCartSize();i++)
		{
			newShoppingCart[i] = user->getShoppingCart()[i];
		}

		//adding the new item
		newShoppingCart[user->getShoppingCartSize()] = products[addToCart];
		newShoppingCart[user->getShoppingCartSize()].setAmount(products[addToCart].getAmount() - 1);
		newShoppingCart[user->getShoppingCartSize()].setAmountInCart(products[addToCart].getAmountInCart() + 1);

		//lower the amount of the product
		products[addToCart].setAmount(products[addToCart].getAmount() - 1);

		//delete old arr and set the pointer to the new one
		delete[] user->getShoppingCart();
		user->setShoppingCart(newShoppingCart);
		//to add
		//delete[] newShoppingCart;

		user->setShoppingCartSize(user->getShoppingCartSize()+1);
	}
	else
	{
		//create array with size 1 and increase size
		user->setShoppingCart(new stock[1]);
		user->setShoppingCartSize(user->getShoppingCartSize() + 1);

		//add product
		user->getShoppingCart()[0] = products[addToCart];
		user->getShoppingCart()[0].setAmount(products[addToCart].getAmount() - 1);
		user->getShoppingCart()[0].setAmountInCart(products[addToCart].getAmountInCart() + 1);

		//lower the amount of the product
		products[addToCart].setAmount(products[addToCart].getAmount() - 1);

		//isFirst = false;
	}
}

void shop::removeFromCart(int removeByID)
{
	int removeFromCart = -1; //index in array of item to be removed

	//find the index in the array of shopping cart of the item to be removed
	for (int i = 0;i < user->getShoppingCartSize();i++)
	{
		if (removeByID == user->getShoppingCart()[i].getID())
		{
			removeFromCart = i;
			break;
		}
	}
	if (removeFromCart == -1)
	{
		cout << "There is no item in cart with that ID.\n";
		Sleep(2000);
		return;
	}

	//if there is only 1 item in cart with amount == 1
	if (user->getShoppingCartSize() == 1 && user->getShoppingCart()[0].getAmountInCart() == 1)
	{
		//find the index of the element in the array of stocks and increase its amount by 1
		for (int i = 0;i < number_Stocks;i++)
		{
			if (user->getShoppingCart()[0].getID() == products[i].getID())
			{
				products[i].setAmount(products[i].getAmount() + 1);
				break;
			}
		}

		//delete
		delete[] user->getShoppingCart();
		user->setShoppingCartSize(0);
		return;
	}

	//if amount in cart is > 1 then lower it
	if (user->getShoppingCart()[removeFromCart].getAmountInCart() > 1)
	{
		user->getShoppingCart()[removeFromCart].setAmountInCart(user->getShoppingCart()[removeFromCart].getAmountInCart() - 1);

		//find the index of the element in the array of stocks and increase its amount by 1
		for (int i = 0;i < number_Stocks;i++)
		{
			if (user->getShoppingCart()[removeFromCart].getID() == products[i].getID())
			{
				products[i].setAmount(products[i].getAmount() + 1);
				break;
			}
		}

		return;
	}
	else if (user->getShoppingCart()[removeFromCart].getAmountInCart() == 1) //(amount==1) make new array with size -=1 and copy everything except the item to be removed
	{
		//find the index of the element in the array of stocks and increase its amount by 1
		for (int i = 0;i < number_Stocks;i++)
		{
			if (user->getShoppingCart()[removeFromCart].getID() == products[i].getID())
			{
				products[i].setAmount(products[i].getAmount() + 1);
				break;
			}
		}

		stock* newShoppingCart = new stock[user->getShoppingCartSize() - 1];
		int k = 0; //counter
		for (int i = 0;i < user->getShoppingCartSize() - 1;i++)
		{
			if (k == removeFromCart) k++; //if k==id of the item to be removed => increase in order to skip
			newShoppingCart[i] = user->getShoppingCart()[k];
			k++;
		}
		user->setShoppingCartSize(user->getShoppingCartSize() - 1);
		delete[] user->getShoppingCart();
		user->setShoppingCart(newShoppingCart);
		//to add
		//delete[] newShoppingCart;

		
	}
}

void shop::createProduct()
{
	//if user not admin - exit
	if (!user->getIsAdmin())
	{
		cout << "Restricted Access!\n";
		Sleep(2000);
		return;
	}

	system("CLS");
	cout << "Now creating a new product...\n\n";

	//temp variables for input
	char name[50];
	char category[20];
	int category_ID;
	int ID;
	int amount;
	double price;
	char description[100];

	//input variables
	cout << "Input name: ";
	cin >> name;
	cout << "Input category name: ";
	cin >> category;
	cout << "Input category ID => 1=Clothes, 2=Food, 3=Tech: ";
	cin >> category_ID;
	cout << "Input ID of product: ";
	cin >> ID;
	cout << "Input amount: ";
	cin >> amount;
	cout << "Input price: ";
	cin >> price;
	cout << "Input description: ";
	cin.ignore();
	cin.getline(description, 100);

	//create new array with +1 size
	stock* newProducts = new stock[number_Stocks + 1];

	//copy old array in new array
	for (int i = 0;i < number_Stocks;i++)
	{
		newProducts[i].setName(products[i].getName());
		newProducts[i].setCategory(products[i].getCategory());
		newProducts[i].setCategory_ID(products[i].getCategory_ID());
		newProducts[i].setID(products[i].getID());
		newProducts[i].setAmount(products[i].getAmount());
		newProducts[i].setAmountInCart(products[i].getAmountInCart());
		newProducts[i].setPrice(products[i].getPrice());
		newProducts[i].setDescription(products[i].getDescription());
	}
	//add new product to array
	newProducts[number_Stocks].setName(name);
	newProducts[number_Stocks].setCategory(category);
	newProducts[number_Stocks].setCategory_ID(category_ID);
	newProducts[number_Stocks].setID(ID);
	newProducts[number_Stocks].setAmount(amount);
	newProducts[number_Stocks].setAmountInCart(0);
	newProducts[number_Stocks].setPrice(price);
	newProducts[number_Stocks].setDescription(description);

	//delete old array
	delete[] products;
	products = newProducts;
	//to add
	//delete[] newProducts

	//increase size
	number_Stocks++;

	//add product to database
	ofstream addProduct;
	addProduct.open("stocks.txt", ios::app);
	addProduct << name << ' ' << category << ' ' << category_ID << ' ' << ID << ' ' << amount << ' ' << 0 << ' ' << price << ' ' << description << endl;
	addProduct.close();
}

void shop::updateDataToFile()
{
	ofstream updateData;
	updateData.open("stocks.txt", ios::out | ios::trunc);
	for (int i = 0;i < getNumberStocks();i++)
	{
		updateData << getProducts()[i].getName() << ' ' << getProducts()[i].getCategory() << ' '
			<< getProducts()[i].getCategory_ID() << ' ' << getProducts()[i].getID() << ' '
			<< getProducts()[i].getAmount() << ' ' << getProducts()[i].getAmountInCart() << ' '
			<< getProducts()[i].getPrice() << ' ' << getProducts()[i].getDescription() << endl;
	}
	updateData.close();
}

