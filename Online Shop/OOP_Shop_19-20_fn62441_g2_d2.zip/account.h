#pragma once
#pragma warning(disable:4996)
#include "stock.h"

class account 
{
	char* username;
	char* password;
	bool isAdmin;
	int shoppingCartSize;
	stock* shoppingCart;
public:
	//constructors
	account();
	account(const char*, const char*);
	~account();

	//getters
	const char* getUsername() const;
	const char* getPassword() const;
	bool getIsAdmin() const;
	int getShoppingCartSize() const;
	stock* getShoppingCart() const;

	//setters
	void setUsername(const char*);
	void setPassword(const char*);
	void setIsAdmin(bool);
	void setShoppingCartSize(int);
	void setShoppingCart(stock*);

	//other
	account& operator=(const account& obj);
	account(const account& obj);
	void printUser() const;
	void printShoppingCart() const;
	bool buy(); //return true if a purchase is completed
	
};