#include "stock.h"
#include <cstring>
#include <iostream>
using namespace std;

stock::stock()
{
	name = nullptr;
	category = nullptr;
	category_ID = 0;
	ID = 0;
	amount = 0;
	amountInCart = 0;
	price = 0.0;
	description = nullptr;
}

stock::stock(const char*name,const char*category,int category_ID,int ID, int amount, int amountInCart, double price,const char*description)
{
	this->name = new char[strlen(name)+1];
	strcpy(this->name, name);

	this->category = new char[strlen(category) + 1];
	strcpy(this->category, category);

	this->category_ID = category_ID;
	this->ID = ID;
	this->amount = amount;
	this->amountInCart = amountInCart;
	this->price = price;

	this->description = new char[strlen(description) + 1];
	strcpy(this->description, description);
}

stock::stock(const stock& obj)
{
	name = new char[strlen(obj.name) + 1];
	strcpy(this->name, obj.name);
	category = new char[strlen(obj.category) + 1];
	strcpy(this->category, obj.category);
	description = new char[strlen(obj.description) + 1];
	strcpy(this->description, obj.description);
	this->category_ID = obj.category_ID;
	this->ID = obj.ID;
	this->amount = obj.amount;
	this->amountInCart = obj.amountInCart;
	this->price = obj.price;
}

stock::~stock()
{
	if(name!=nullptr) delete[] name;
	if(category!=nullptr) delete[] category;
	if(description!=nullptr) delete[] description;
}

const char* stock::getName() const
{
	return name;
}

const char* stock::getCategory() const
{
	return category;
}

int stock::getCategory_ID() const
{
	return category_ID;
}

int stock::getID() const
{
	return ID;
}

int stock::getAmount() const
{
	return amount;
}

int stock::getAmountInCart() const
{
	return amountInCart;
}

double stock::getPrice() const
{
	return price;
}

const char* stock::getDescription() const
{
	return description;
}

void stock::setName(const char*name)
{
	if (this != nullptr) delete[] this->name;
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);
}

void stock::setCategory(const char*category)
{
	if (this != nullptr) delete[] this->category;
	this->category = new char[strlen(category) + 1];
	strcpy(this->category, category);
}

void stock::setCategory_ID(int category_ID)
{
	this->category_ID = category_ID;
}

void stock::setID(int ID)
{
	this->ID = ID;
}

void stock::setAmount(int amount)
{
	this->amount = amount;
}

void stock::setAmountInCart(int amountInCart)
{
	this->amountInCart = amountInCart;
}

void stock::setPrice(double price)
{
	this->price = price;
}

void stock::setDescription(const char*description)
{
	if (this != nullptr) delete[] this->description;
	this->description = new char[strlen(description) + 1];
	strcpy(this->description, description);
}

void stock::print() const
{
	if(name!=nullptr && category!=nullptr && description!= nullptr) cout <<"\nProduct ID: "<<ID<<endl<< "Name: " << name << endl << "Category: " << category << endl << "Amount: " << amount << endl << "Price: $" << price << endl << "Description: " << description<<endl;
}

void stock::printForCart() const
{
	if (name != nullptr && category != nullptr && description != nullptr) cout <<"\nProduct ID: "<<ID<<endl<< "Name: " << name << endl << "Price: $" << price << endl << "Description: " << description << endl<<"Amount in cart: "<<amountInCart<<endl;
}

stock& stock::operator=(const stock& obj)
{
	if (this != &obj)
	{
		delete[] name;
		delete[] category;
		delete[] description;
		name = new char[strlen(obj.name) + 1];
		strcpy(this->name, obj.name);
		category = new char[strlen(obj.category) + 1];
		strcpy(this->category, obj.category);
		description = new char[strlen(obj.description) + 1];
		strcpy(this->description, obj.description);
		this->category_ID = obj.category_ID;
		this->ID = obj.ID;
		this->amount = obj.amount;
		this->amountInCart = obj.amountInCart;
		this->price = obj.price;
	}
	return *this;
}


