#pragma once
#pragma warning(disable:4996)

class stock 
{
	char* name;
	char* category;
	char* description;
	int category_ID;
	int ID;
	int amount;
	int amountInCart;
	double price;
public:
	//constructors
	stock();
	stock(const char*,const char*, int, int, int, int, double,const char*);
	stock(const stock& obj);
	~stock();

	//getters
	const char* getName() const;
	const char* getCategory() const;
	const char* getDescription() const;
	int getCategory_ID() const;
	int getID() const;
	int getAmount() const;
	int getAmountInCart() const;
	double getPrice() const;

	//setters
	void setName(const char*);
	void setCategory(const char*);
	void setCategory_ID(int);
	void setID(int);
	void setAmount(int);
	void setAmountInCart(int);
	void setPrice(double);
	void setDescription(const char*);

	//other
	void print() const;
	void printForCart() const;
	stock& operator=(const stock& obj);
};