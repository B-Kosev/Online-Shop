#include "account.h"
#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;

account::account()
{
	username = nullptr;
	password = nullptr;
	isAdmin = false;
	shoppingCartSize = 0;
	shoppingCart = nullptr;
}

account::account(const char* username, const char* password)
{
	this->username = new char[strlen(username) + 1];
	strcpy(this->username, username);

	this->password = new char[strlen(password) + 1];
	strcpy(this->password, password);
	isAdmin = false;
	shoppingCartSize = 0;
	shoppingCart = nullptr;
}

account::~account()
{
	if(username!=nullptr) delete[] username;
	if(password!=nullptr) delete[] password;
	if(shoppingCart!=nullptr) delete[] shoppingCart;
}

const char* account::getUsername() const
{
	return username;
}

const char* account::getPassword() const
{
	return password;
}

bool account::getIsAdmin() const
{
	return isAdmin;
}

int account::getShoppingCartSize() const
{
	return shoppingCartSize;
}

stock* account::getShoppingCart() const
{
	return shoppingCart;
}

void account::setUsername(const char*username)
{
	if(this->username!=nullptr) delete[] this->username;
	this->username = new char[strlen(username) + 1];
	strcpy(this->username, username);
}

void account::setPassword(const char*password)
{
	if (this->password != nullptr) delete[] this->password;
	this->password = new char[strlen(password) + 1];
	strcpy(this->password, password);
}

void account::setIsAdmin(bool isAdmin)
{
	this->isAdmin = isAdmin;
}

void account::setShoppingCartSize(int size)
{
	this->shoppingCartSize = size;
}

void account::setShoppingCart(stock* shoppingCart)
{
	//if(this->shoppingCart!=nullptr) delete[] this->shoppingCart; //tuk mi dava greshka i ne moga da prosledq zashto
	this->shoppingCart = shoppingCart;
}

account& account::operator=(const account& obj)
{
	if (this != &obj)
	{
		delete[] username;
		delete[] password;
		delete[] shoppingCart;
		username = new char[strlen(obj.username) + 1];
		strcpy(username, obj.username);
		password = new char[strlen(obj.password) + 1];
		strcpy(password, obj.password);
		isAdmin = obj.isAdmin;
		shoppingCartSize = obj.shoppingCartSize;
		shoppingCart = new stock[shoppingCartSize];
		shoppingCart = obj.shoppingCart;
	}
	return *this;
}

account::account(const account& obj)
{
	username = new char[strlen(obj.username) + 1];
	strcpy(username, obj.username);
	password = new char[strlen(obj.password) + 1];
	strcpy(password, obj.password);
	isAdmin = obj.isAdmin;
	shoppingCartSize = obj.shoppingCartSize;
	shoppingCart = new stock[shoppingCartSize];
	shoppingCart = obj.shoppingCart;
}

void account::printUser() const
{
	if(username!=nullptr && password!= nullptr) cout << "Username: " << username << endl << "Password: " << password << endl<<"Is Admin? " <<isAdmin<<endl;
}

void account::printShoppingCart() const
{
	double priceSum = 0.0;
	cout << "\n--------------------------------------------------------\n";
	cout << "\nShopping cart: \n\n";
	if (shoppingCartSize==0)
	{
		cout << "Empty.\n";
	}
	else
	{
		for (int i = 0;i < shoppingCartSize;i++)
		{
			shoppingCart[i].printForCart();
			cout << endl;
			priceSum += shoppingCart[i].getAmountInCart() * shoppingCart[i].getPrice();
		}
	}
	cout << "\nTotal: " << priceSum << endl;
}

bool account::buy() 
{
	//if there are no items in cart
	if (shoppingCartSize==0)
	{
		cout << "You don't have any items in the cart.\n";
		return false;
	}

	//restrict access to admin only
	if (!isAdmin)
	{
		cout << "You don't have access to this feature yet. Only admin can buy items.\n";
		return false;
	}
	
	//remove all items from the cart
	delete[] shoppingCart;
	setShoppingCart(nullptr);
	shoppingCartSize = 0;

	cout << "Purchase completed!\n";

	return true;
}

